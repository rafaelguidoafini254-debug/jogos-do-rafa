# Cronômetro Impostor

Jogo de festa: todo mundo recebe um tempo secreto, menos o impostor. Cada um aperta o botão (pi), conta de cabeça e aperta de novo (pi). Depois a galera vê os tempos, conversa e vota pra eliminar o impostor.

Modos:
- **Jogar online**: salas **abertas** (aparecem na lista pra qualquer um) e **privadas** (só entra com o código de 4 letras ou o link).
- **Impostor no mesmo celular**: passando o celular de mão em mão.
- **Treinar sozinho**: acerte o tempo e veja quanto errou.

---

## Como colocar no ar (grátis, uns 20 minutos)

Faça isso num computador, porque subir os arquivos pelo celular é chato.

### 1. Coloque os arquivos no GitHub
1. Crie uma conta em **github.com** (se ainda não tiver).
2. Clique no **+** no canto de cima → **New repository**.
3. Nome: `cronometro-impostor`. Deixe **Public**. Clique em **Create repository**.
4. Na página que abrir, clique no link **uploading an existing file**.
5. Descompacte o zip no seu computador e **arraste tudo que está dentro da pasta** `cronometro-impostor` pra página (o `server.js`, o `package.json`, o `render.yaml`, este `README.md`, o `.gitignore` e a pasta `public`).
6. Clique em **Commit changes**.

> Confira se a pasta `public` com o `index.html` dentro apareceu no GitHub. Se não apareceu, arraste a pasta `public` de novo.

### 2. Publique no Render
1. Crie uma conta em **render.com** entrando com o GitHub (botão "GitHub").
2. Clique em **New +** → **Web Service**.
3. Escolha o repositório `cronometro-impostor` (se não aparecer, clique em "Configure account" e dê acesso a ele).
4. Preencha:
   - **Language/Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** **Free**
5. Clique em **Deploy Web Service** e espere uns 2 a 5 minutos até aparecer **Live**.
6. O endereço do seu site aparece no topo, tipo `https://cronometro-impostor-xxxx.onrender.com`. É esse link que você manda pra galera.

### Como jogar online
1. Abra o site → **Jogar online** → escolha um apelido.
2. **Criar sala**: escolha **Aberta** ou **Privada**. Vai aparecer um código, tipo `KXPD`.
3. Os amigos entram pela lista de salas abertas, digitando o código, ou pelo botão **Copiar link** (o link já leva direto pra sala).
4. Quem criou a sala (👑) escolhe quantos impostores e a faixa de tempo, e aperta **Começar rodada** (mínimo 3 jogadores).

### Bom saber
- **Primeiro acesso demora:** no plano grátis do Render o servidor "dorme" depois de 15 minutos sem ninguém. A primeira pessoa que abrir o site espera uns 50 segundos; depois fica rápido.
- **Salas não ficam salvas:** se o servidor reiniciar (ou dormir), as salas somem. É só criar outra.
- **Até 12 jogadores por sala.** Se o anfitrião sair, outra pessoa vira anfitrião.
- **Caiu a internet ou bloqueou o celular?** Abrindo o site de novo em até 45 segundos você volta pra mesma sala.
- **Som:** se o "pi" não tocar no iPhone, tire o celular do modo silencioso.

### Mudar alguma coisa depois
Edite o arquivo no GitHub (clique no arquivo → ícone de lápis → **Commit changes**). O Render atualiza o site sozinho em alguns minutos.

### Rodar no próprio computador (opcional)
Com o Node.js 18 ou mais novo instalado:
```
npm install
npm start
```
E abra `http://localhost:3000`.

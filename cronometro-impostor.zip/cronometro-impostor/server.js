// Cronômetro Impostor — servidor de salas
// Node + Express + Socket.IO. Guarda tudo em memória (salas somem se o servidor reiniciar).
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const express = require('express');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_req, res) => res.send('ok'));

const MAX_PLAYERS = 12;
const VOTE_SECONDS = 120;
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const rooms = new Map(); // code -> room

const rid = (n = 8) => crypto.randomBytes(n).toString('hex');
const clean = (s, n) => String(s ?? '').replace(/[\u0000-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim().slice(0, n);
const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
function newCode() {
  let c;
  do { c = Array.from({ length: 4 }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join(''); } while (rooms.has(c));
  return c;
}

/* ---------- helpers ---------- */
const connectedPlayers = room => [...room.players.values()].filter(p => p.connected);
const participants = room => [...room.players.values()].filter(p => p.inRound && p.connected);

function publicRooms() {
  return [...rooms.values()]
    .filter(r => r.isPublic && connectedPlayers(r).length > 0)
    .map(r => ({ code: r.code, name: r.name, players: connectedPlayers(r).length, max: MAX_PLAYERS, phase: r.phase }))
    .sort((a, b) => (a.phase === 'lobby' ? 0 : 1) - (b.phase === 'lobby' ? 0 : 1) || b.players - a.players);
}
let listTimer = null;
function broadcastList() {
  if (listTimer) return;
  listTimer = setTimeout(() => { listTimer = null; io.to('room-list').emit('rooms', publicRooms()); }, 150);
}

function viewFor(room, me) {
  const players = [...room.players.values()].map(p => ({
    pid: p.pid, name: p.name, connected: p.connected, host: p.token === room.host, score: p.score,
    inRound: p.inRound,
    done: room.phase === 'timing' ? p.inRound && room.times[p.pid] !== undefined : undefined,
    voted: room.phase === 'voting' ? p.inRound && room.votes[p.pid] !== undefined : undefined,
  }));
  const v = {
    code: room.code, name: room.name, isPublic: room.isPublic, phase: room.phase, round: room.round,
    settings: room.settings, players, me: me.pid, isHost: me.token === room.host,
    remaining: room.deadline ? Math.max(0, room.deadline - Date.now()) : null,
  };
  if (room.phase !== 'lobby' && me.inRound) {
    const imp = room.imps.has(me.pid);
    v.role = { impostor: imp, target: imp ? null : room.target, impCount: room.imps.size };
    v.myTime = room.times[me.pid] ?? null;
    v.myVote = room.votes[me.pid] ?? null;
  }
  if (room.phase === 'voting' || room.phase === 'reveal') v.times = room.times;
  if (room.phase === 'reveal') v.reveal = room.reveal;
  return v;
}
function emitState(room) {
  for (const p of room.players.values()) if (p.connected && p.sid) io.to(p.sid).emit('state', viewFor(room, p));
}
function sysChat(room, text) {
  const m = { sys: true, text, at: Date.now() };
  room.chat.push(m); room.chat = room.chat.slice(-60);
  io.to('r:' + room.code).emit('chat', m);
}

/* ---------- game flow ---------- */
function startRound(room) {
  const ps = connectedPlayers(room);
  if (ps.length < 3) return 'Precisa de pelo menos 3 jogadores conectados.';
  clearTimeout(room.timer);
  for (const p of room.players.values()) p.inRound = p.connected;
  const n = ps.length;
  const impCount = Math.max(1, Math.min(room.settings.impostors, Math.floor((n - 1) / 2)));
  room.imps = new Set(shuffle(ps.map(p => p.pid)).slice(0, impCount));
  const { minT, maxT } = room.settings;
  room.target = (minT + Math.floor(Math.random() * (maxT - minT + 1))) * 1000;
  room.times = {}; room.votes = {}; room.reveal = null;
  room.round++;
  room.phase = 'timing';
  room.deadline = Date.now() + (maxT * 2 + 60) * 1000;
  room.timer = setTimeout(() => toVoting(room), room.deadline - Date.now());
  sysChat(room, `Rodada ${room.round} começou.`);
  emitState(room); broadcastList();
  return null;
}
function checkTiming(room) {
  if (room.phase !== 'timing') return;
  const ps = participants(room);
  if (ps.length && ps.every(p => room.times[p.pid] !== undefined)) toVoting(room);
}
function toVoting(room) {
  if (room.phase !== 'timing') return;
  clearTimeout(room.timer);
  room.phase = 'voting';
  room.deadline = Date.now() + VOTE_SECONDS * 1000;
  room.timer = setTimeout(() => resolveVotes(room), VOTE_SECONDS * 1000);
  sysChat(room, 'Hora de votar! Quem é o impostor?');
  emitState(room); broadcastList();
}
function checkVoting(room) {
  if (room.phase !== 'voting') return;
  const ps = participants(room);
  if (ps.length && ps.every(p => room.votes[p.pid] !== undefined)) resolveVotes(room);
}
function resolveVotes(room) {
  if (room.phase !== 'voting') return;
  clearTimeout(room.timer);
  const tally = {};
  for (const v of Object.values(room.votes)) if (v !== 'skip') tally[v] = (tally[v] || 0) + 1;
  const max = Math.max(0, ...Object.values(tally));
  const top = Object.keys(tally).filter(k => tally[k] === max);
  const eliminated = max > 0 && top.length === 1 ? top[0] : null;
  const caught = eliminated !== null && room.imps.has(eliminated);

  const byPid = Object.fromEntries([...room.players.values()].map(p => [p.pid, p]));
  const inRound = [...room.players.values()].filter(p => p.inRound);
  if (caught) inRound.filter(p => !room.imps.has(p.pid)).forEach(p => p.score += 1);
  else room.imps.forEach(pid => { if (byPid[pid]) byPid[pid].score += 3; });
  let best = null;
  for (const p of inRound) {
    if (room.imps.has(p.pid) || room.times[p.pid] == null) continue;
    if (!best || Math.abs(room.times[p.pid] - room.target) < Math.abs(room.times[best] - room.target)) best = p.pid;
  }
  if (best) byPid[best].score += 1;

  room.reveal = { impostors: [...room.imps], target: room.target, eliminated, caught, tally, best,
    bestDiff: best ? Math.abs(room.times[best] - room.target) : null, tie: max > 0 && top.length > 1 };
  room.phase = 'reveal'; room.deadline = null;
  emitState(room); broadcastList();
}
function backToLobby(room) {
  clearTimeout(room.timer);
  room.phase = 'lobby'; room.deadline = null; room.times = {}; room.votes = {}; room.reveal = null; room.imps = new Set();
  for (const p of room.players.values()) p.inRound = false;
  emitState(room); broadcastList();
}
function ensureHost(room) {
  const host = room.players.get(room.host);
  if (host && host.connected) return;
  const next = connectedPlayers(room)[0];
  if (next) { room.host = next.token; sysChat(room, `${next.name} agora é o anfitrião.`); }
}
function removePlayer(room, token) {
  const p = room.players.get(token); if (!p) return;
  room.players.delete(token);
  sysChat(room, `${p.name} saiu.`);
  if (!room.players.size) { clearTimeout(room.timer); rooms.delete(room.code); broadcastList(); return; }
  ensureHost(room);
  checkTiming(room); checkVoting(room);
  emitState(room); broadcastList();
}

/* ---------- sockets ---------- */
io.on('connection', socket => {
  let current = null; // { room, token }
  let lastChat = 0;
  const reply = (cb, data) => { if (typeof cb === 'function') cb(data); };
  const mine = () => current && rooms.get(current.room.code) === current.room ? current.room.players.get(current.token) : null;

  socket.on('watch-rooms', on => {
    if (on) { socket.join('room-list'); socket.emit('rooms', publicRooms()); } else socket.leave('room-list');
  });

  function attach(room, token, name, cb) {
    let p = room.players.get(token);
    if (!p) {
      if (room.players.size >= MAX_PLAYERS) return reply(cb, { error: 'A sala está cheia.' });
      let nm = name, i = 2;
      const names = new Set([...room.players.values()].map(x => x.name.toLowerCase()));
      while (names.has(nm.toLowerCase())) nm = `${name} ${i++}`;
      p = { token, pid: rid(4), name: nm, score: 0, inRound: false, connected: true, sid: socket.id };
      room.players.set(token, p);
      sysChat(room, `${p.name} entrou.`);
    } else {
      if (p.sid && p.sid !== socket.id) io.to(p.sid).emit('kicked', 'Você entrou nesta sala em outra aba.');
      p.connected = true; p.sid = socket.id; clearTimeout(p.dropTimer);
    }
    if (current && current.room !== room) leaveCurrent(false);
    current = { room, token };
    socket.join('r:' + room.code);
    if (!room.players.get(room.host)?.connected) room.host = token;
    reply(cb, { ok: true, code: room.code, chat: room.chat });
    emitState(room); broadcastList();
  }

  socket.on('create', (data, cb) => {
    const name = clean(data?.nick, 16); const token = clean(data?.token, 40);
    if (!name || token.length < 8) return reply(cb, { error: 'Escolha um apelido.' });
    const code = newCode();
    const room = {
      code, name: clean(data?.roomName, 28) || `Sala de ${name}`, isPublic: !!data?.isPublic, host: token,
      players: new Map(), settings: { impostors: 1, minT: 3, maxT: 15, showTime: false }, phase: 'lobby', round: 0,
      target: 0, imps: new Set(), times: {}, votes: {}, reveal: null, deadline: null, timer: null, chat: [],
    };
    rooms.set(code, room);
    attach(room, token, name, cb);
  });

  socket.on('join', (data, cb) => {
    const code = clean(data?.code, 8).toUpperCase(); const name = clean(data?.nick, 16); const token = clean(data?.token, 40);
    const room = rooms.get(code);
    if (!room) return reply(cb, { error: 'Sala não encontrada. Confira o código.' });
    if (!name || token.length < 8) return reply(cb, { error: 'Escolha um apelido.' });
    attach(room, token, name, cb);
  });

  function leaveCurrent(notify = true) {
    if (!current) return;
    const { room, token } = current; current = null;
    socket.leave('r:' + room.code);
    if (rooms.get(room.code) === room) removePlayer(room, token);
    if (notify) socket.emit('left');
  }
  socket.on('leave', () => leaveCurrent(true));

  socket.on('settings', s => {
    const p = mine(); if (!p) return; const room = current.room;
    if (room.host !== p.token || room.phase !== 'lobby') return;
    const st = room.settings;
    const num = (v, lo, hi, d) => Number.isFinite(+v) ? Math.max(lo, Math.min(hi, Math.round(+v))) : d;
    st.impostors = num(s?.impostors, 1, 5, st.impostors);
    st.maxT = num(s?.maxT, 2, 60, st.maxT);
    st.minT = num(s?.minT, 1, st.maxT - 1, st.minT);
    if (typeof s?.isPublic === 'boolean') room.isPublic = s.isPublic;
    if (typeof s?.showTime === 'boolean') st.showTime = s.showTime;
    emitState(room); broadcastList();
  });

  socket.on('start', (_d, cb) => {
    const p = mine(); if (!p) return; const room = current.room;
    if (room.host !== p.token) return reply(cb, { error: 'Só o anfitrião pode começar.' });
    if (room.phase === 'timing' || room.phase === 'voting') return;
    const err = startRound(room); reply(cb, err ? { error: err } : { ok: true });
  });
  socket.on('lobby', () => {
    const p = mine(); if (!p) return; const room = current.room;
    if (room.host === p.token && room.phase === 'reveal') backToLobby(room);
  });

  socket.on('time', ms => {
    const p = mine(); if (!p) return; const room = current.room;
    if (room.phase !== 'timing' || !p.inRound || room.times[p.pid] !== undefined) return;
    const v = Number(ms); if (!Number.isFinite(v)) return;
    room.times[p.pid] = Math.max(0, Math.min(180000, Math.round(v)));
    emitState(room); checkTiming(room);
  });

  socket.on('vote', target => {
    const p = mine(); if (!p) return; const room = current.room;
    if (room.phase !== 'voting' || !p.inRound || room.votes[p.pid] !== undefined) return;
    const valid = target === 'skip' || [...room.players.values()].some(x => x.pid === target && x.inRound);
    if (!valid) return;
    room.votes[p.pid] = target;
    emitState(room); checkVoting(room);
  });

  socket.on('kick', pid => {
    const p = mine(); if (!p) return; const room = current.room;
    if (room.host !== p.token) return;
    const t = [...room.players.values()].find(x => x.pid === pid && x.token !== p.token);
    if (!t) return;
    if (t.sid) { io.to(t.sid).emit('kicked', 'O anfitrião tirou você da sala.'); io.in(t.sid).socketsLeave('r:' + room.code); }
    removePlayer(room, t.token);
  });

  socket.on('chat', text => {
    const p = mine(); if (!p) return;
    const now = Date.now(); if (now - lastChat < 600) return; lastChat = now;
    const t = clean(text, 200); if (!t) return;
    const room = current.room;
    const m = { pid: p.pid, name: p.name, text: t, at: now };
    room.chat.push(m); room.chat = room.chat.slice(-60);
    io.to('r:' + room.code).emit('chat', m);
  });

  socket.on('disconnect', () => {
    const p = mine(); if (!p || p.sid !== socket.id) return;
    const room = current.room;
    p.connected = false; p.sid = null;
    ensureHost(room);
    // give 45s to come back (phone locked, network blip) before removing from the room
    p.dropTimer = setTimeout(() => { if (!p.connected && rooms.get(room.code) === room) removePlayer(room, p.token); }, 45000);
    checkTiming(room); checkVoting(room);
    emitState(room); broadcastList();
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Cronômetro Impostor rodando em http://localhost:${PORT}`));
